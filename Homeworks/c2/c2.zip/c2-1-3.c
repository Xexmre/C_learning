#include <stdio.h>

int main(void){
    printf("春眠不觉晓\n");
    printf("\t处处闻啼鸟\n");
    printf("\t\t夜来风雨声\n");
    printf("\t\t\t花落知多少\n");
    return 0;
}