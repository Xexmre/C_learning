#include <stdio.h>
int main(void){
    float fa, fb;
    printf("Input x and y:\n");
    scanf("%f%f", &fa, &fb);
    printf("float类型数据的打印结果：\n");
    printf("fa=%10.3f\t fb=%.3f\n", fa, fb);
    return 0;
}